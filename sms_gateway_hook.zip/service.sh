#!/system/bin/sh
# service.sh — SMS Gateway Hook + SSAID Changer
MODDIR="${0%/*}"
TAG="SmsGateHook"
CONFIG="/data/local/tmp/sms_hook_config.txt"

log -t "$TAG" -p i "═══ SMS Gateway Hook v1.0 ═══"

# ── CRITICAL: Write login status FIRST (before any Zygisk process checks it) ──
# Zygisk processes fork from Zygote very early — they check this file before
# service.sh has a chance to write the config. Without this, the first process
# writes DENIED and ALL subsequent processes skip DEX loading.
echo "VALID" > /data/local/tmp/sms_hook_login_status
chmod 644 /data/local/tmp/sms_hook_login_status
log -t "$TAG" -p i "Login status set to VALID (pre-config)"

# Clean up inject lock file on boot (so watcher starts fresh)
rm -f /data/local/tmp/.sms_inject_lock 2>/dev/null
rm -f /data/local/tmp/inject_sms.txt 2>/dev/null
# Set SELinux context so app processes can access /data/local/tmp
chcon -R u:object_r:shell_data_file:s0 /data/local/tmp 2>/dev/null

# Create default config if not exists
if [ ! -f "$CONFIG" ]; then
    cat > "$CONFIG" << 'EOF'
# SMS Gateway Hook Config
# Edit values and save — changes apply instantly (no reboot needed)
#
# Phone number spoof (all apps see this number)
phone_number=+919855456825
#
# Device ID / IMEI spoof (leave empty to use real IMEI)
device_id=
#
# Android ID spoof (16-char hex, leave empty to use real)
android_id=
EOF
    log -t "$TAG" -p i "Created default config: $CONFIG"
fi

# Ensure config is world-readable
chmod 644 "$CONFIG"
chcon u:object_r:shell_data_file:s0 "$CONFIG" 2>/dev/null

# ── Android ID / SSAID Spoof ──
# Read android_id from config and change EVERY app's SSAID
AID=$(grep -i "^android_id=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
if [ -n "$AID" ] && [ ${#AID} -eq 16 ]; then
    log -t "$TAG" -p i "SSAID: Spoofing ALL android_ids → $AID"
    
    # 1. Set global android_id
    settings put secure android_id "$AID" 2>/dev/null
    log -t "$TAG" -p i "SSAID: Global set"
    
    # 2. Get list of ALL installed packages and change each one's SSAID
    for PKG in $(pm list packages 2>/dev/null | cut -d: -f2); do
        # Use content provider to set per-app SSAID
        content call --uri content://settings/ssaid \
            --method PUT_ssaid \
            --arg "$PKG" \
            --extra _user:i:0 \
            --extra value:s:"$AID" 2>/dev/null
    done
    log -t "$TAG" -p i "SSAID: All per-app SSAIDs set → $AID"
fi

# ── Read SIM mock config fields ──
SIM_ENABLED=$(grep -i "^sim_enabled=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
SIM_CARRIER=$(grep -i "^sim_carrier_name=" "$CONFIG" 2>/dev/null | cut -d= -f2)
SIM_MCC=$(grep -i "^sim_mcc=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
SIM_MNC=$(grep -i "^sim_mnc=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
SIM_ICCID=$(grep -i "^sim_iccid=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
SIM_IMSI=$(grep -i "^sim_imsi=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
SIM_COUNTRY=$(grep -i "^sim_country_iso=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')

# ── Phone Number Database Spoof (background — telephony needs time to start) ──
SPOOF_NUM=$(grep -i "^phone_number=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
if [ -n "$SPOOF_NUM" ]; then
    (
        log -t "$TAG" -p i "PHONE SPOOF: Will update telephony DB → $SPOOF_NUM"
        [ -n "$SIM_CARRIER" ] && log -t "$TAG" -p i "SIM MOCK: Carrier=$SIM_CARRIER MCC=$SIM_MCC MNC=$SIM_MNC"

        # Retry loop — wait for telephony content provider to be available
        for i in $(seq 1 15); do
            sleep 2
            SIM_IDS=$(content query --uri content://telephony/siminfo --projection _id 2>/dev/null | grep -o '_id=[0-9]*' | cut -d= -f2)
            if [ -n "$SIM_IDS" ]; then
                for SIM_ID in $SIM_IDS; do
                    # Phone number
                    content update --uri content://telephony/siminfo \
                        --bind number:s:"$SPOOF_NUM" \
                        --where "_id=$SIM_ID" 2>/dev/null
                    content update --uri content://telephony/siminfo \
                        --bind phone_number_source_ims:s:"$SPOOF_NUM" \
                        --where "_id=$SIM_ID" 2>/dev/null
                    content update --uri content://telephony/siminfo \
                        --bind phone_number_source_carrier:s:"$SPOOF_NUM" \
                        --where "_id=$SIM_ID" 2>/dev/null

                    # Carrier display name
                    if [ -n "$SIM_CARRIER" ]; then
                        content update --uri content://telephony/siminfo \
                            --bind carrier_name:s:"$SIM_CARRIER" \
                            --where "_id=$SIM_ID" 2>/dev/null
                        content update --uri content://telephony/siminfo \
                            --bind display_name:s:"$SIM_CARRIER" \
                            --where "_id=$SIM_ID" 2>/dev/null
                    fi

                    # MCC / MNC
                    if [ -n "$SIM_MCC" ]; then
                        content update --uri content://telephony/siminfo \
                            --bind mcc:i:"$SIM_MCC" \
                            --where "_id=$SIM_ID" 2>/dev/null
                        content update --uri content://telephony/siminfo \
                            --bind mcc_string:s:"$SIM_MCC" \
                            --where "_id=$SIM_ID" 2>/dev/null
                    fi
                    if [ -n "$SIM_MNC" ]; then
                        content update --uri content://telephony/siminfo \
                            --bind mnc:i:"$SIM_MNC" \
                            --where "_id=$SIM_ID" 2>/dev/null
                        content update --uri content://telephony/siminfo \
                            --bind mnc_string:s:"$SIM_MNC" \
                            --where "_id=$SIM_ID" 2>/dev/null
                    fi

                    # Country ISO
                    if [ -n "$SIM_COUNTRY" ]; then
                        content update --uri content://telephony/siminfo \
                            --bind iso_country_code:s:"$SIM_COUNTRY" \
                            --where "_id=$SIM_ID" 2>/dev/null
                    fi

                    # ICCID
                    if [ -n "$SIM_ICCID" ]; then
                        content update --uri content://telephony/siminfo \
                            --bind icc_id:s:"$SIM_ICCID" \
                            --where "_id=$SIM_ID" 2>/dev/null
                    fi

                    log -t "$TAG" -p i "PHONE SPOOF: SIM $SIM_ID → $SPOOF_NUM (number + IMS + carrier)"
                    [ -n "$SIM_CARRIER" ] && log -t "$TAG" -p i "SIM MOCK: SIM $SIM_ID → carrier=$SIM_CARRIER mcc=$SIM_MCC mnc=$SIM_MNC"
                done

                # Set system properties via resetprop
                resetprop persist.radio.msisdn "$SPOOF_NUM" 2>/dev/null
                resetprop gsm.sim.num "$SPOOF_NUM" 2>/dev/null

                # Set carrier-related system properties
                if [ -n "$SIM_MCC" ] && [ -n "$SIM_MNC" ]; then
                    resetprop gsm.sim.operator.numeric "${SIM_MCC}${SIM_MNC}" 2>/dev/null
                    resetprop gsm.operator.numeric "${SIM_MCC}${SIM_MNC}" 2>/dev/null
                fi
                if [ -n "$SIM_CARRIER" ]; then
                    resetprop gsm.sim.operator.alpha "$SIM_CARRIER" 2>/dev/null
                    resetprop gsm.operator.alpha "$SIM_CARRIER" 2>/dev/null
                fi
                if [ -n "$SIM_COUNTRY" ]; then
                    resetprop gsm.sim.operator.iso-country "$SIM_COUNTRY" 2>/dev/null
                    resetprop gsm.operator.iso-country "$SIM_COUNTRY" 2>/dev/null
                fi

                log -t "$TAG" -p i "PHONE SPOOF: ✓ DB + props spoofed (attempt $i)"
                break
            fi
            log -t "$TAG" -p i "PHONE SPOOF: Waiting for telephony... (attempt $i/15)"
        done
    ) &
fi

log -t "$TAG" -p i "Config: $CONFIG (world-readable)"

# ── SMS Injection Relay (Direct TCP to system_server) ──
# User writes "sender|message" to /data/local/tmp/inject_sms.txt
# Relay reads it, deletes it, sends INJECT:sender|message to system_server TCP
# system_server (UID 1000) broadcasts SMS_DELIVER + SMS_RECEIVED
# NO intermediate files, NO watcher thread, NO SELinux issues

INJECT_SRC="/data/local/tmp/inject_sms.txt"
TCP_PORT=19876
rm -f "$INJECT_SRC" 2>/dev/null

log -t "$TAG" -p i "SMS inject relay: $INJECT_SRC → TCP 127.0.0.1:$TCP_PORT (direct)"

(
    while true; do
        sleep 1
        [ ! -f "$INJECT_SRC" ] && continue

        # Read content, strip UTF-16 BOM + null bytes
        CONTENT=$(tr -cd '\11\12\15\40-\176' < "$INJECT_SRC" 2>/dev/null)
        rm -f "$INJECT_SRC" 2>/dev/null

        # Only send if we got content with a pipe separator
        if [ -n "$CONTENT" ]; then
            # Send directly to system_server TCP (no intermediate file)
            echo "INJECT:$CONTENT" | nc 127.0.0.1 $TCP_PORT 2>/dev/null
            log -t "$TAG" -p i "[RELAY] Sent INJECT via TCP → $CONTENT"
        fi
    done
) &

log -t "$TAG" -p i "SMS inject relay PID: $!"

# ── Config Change Watcher (live SIM number update without reboot) ──
# Polls config every 5s. When phone_number changes, sends UPDATE_NUMBER
# to system_server TCP → updates telephony DB + invalidates framework cache
# → Settings "Mobile Networks" shows new number immediately
(
    LAST_SPOOF_NUM="$SPOOF_NUM"
    sleep 45  # Wait for system_server TCP to be ready

    log -t "$TAG" -p i "CONFIG WATCHER: Active (polling every 5s)"

    while true; do
        sleep 5
        CURR_NUM=$(grep -i "^phone_number=" "$CONFIG" 2>/dev/null | cut -d= -f2 | tr -d '[:space:]')
        [ -z "$CURR_NUM" ] && continue

        if [ "$CURR_NUM" != "$LAST_SPOOF_NUM" ]; then
            log -t "$TAG" -p i "CONFIG WATCHER: phone_number changed $LAST_SPOOF_NUM → $CURR_NUM"

            # ── Step 1: Update telephony DB as ROOT (UID 0) ──
            # The `number` column is protected on Android 13+ — only root can write it
            # UID 1000 (system_server) can write phone_number_source_* but NOT `number`
            SIM_IDS=$(content query --uri content://telephony/siminfo --projection _id 2>/dev/null | grep -o '_id=[0-9]*' | cut -d= -f2)
            for SIM_ID in $SIM_IDS; do
                content update --uri content://telephony/siminfo \
                    --bind number:s:"$CURR_NUM" \
                    --where "_id=$SIM_ID" 2>/dev/null
                content update --uri content://telephony/siminfo \
                    --bind phone_number_source_ims:s:"$CURR_NUM" \
                    --where "_id=$SIM_ID" 2>/dev/null
                content update --uri content://telephony/siminfo \
                    --bind phone_number_source_carrier:s:"$CURR_NUM" \
                    --where "_id=$SIM_ID" 2>/dev/null
                log -t "$TAG" -p i "CONFIG WATCHER: SIM $SIM_ID DB → $CURR_NUM"
            done

            # ── Step 2: Update system properties ──
            resetprop persist.radio.msisdn "$CURR_NUM" 2>/dev/null
            resetprop gsm.sim.num "$CURR_NUM" 2>/dev/null

            # Ensure DB commits are flushed before notifying
            sleep 2

            # ── Step 3: Verify DB was actually updated ──
            DB_NUM=$(content query --uri content://telephony/siminfo --projection number 2>/dev/null | grep -o 'number=[^ ]*' | head -1 | cut -d= -f2)
            if [ "$DB_NUM" != "$CURR_NUM" ]; then
                log -t "$TAG" -p w "CONFIG WATCHER: DB verify FAILED (got=$DB_NUM, expected=$CURR_NUM) — retrying"
                for SIM_ID in $SIM_IDS; do
                    content update --uri content://telephony/siminfo \
                        --bind number:s:"$CURR_NUM" \
                        --where "_id=$SIM_ID" 2>/dev/null
                done
                sleep 1
            fi

            # ── Step 4: Tell system_server to invalidate SubscriptionController cache ──
            # DB is already updated by root above; this only refreshes the in-memory cache
            echo "UPDATE_NUMBER:$CURR_NUM" | nc 127.0.0.1 $TCP_PORT 2>/dev/null

            # ── Step 5: Force-kill Settings/SIM apps to clear stale SubscriptionInfo cache ──
            # Each app process caches SubscriptionInfo locally; killing forces fresh read
            # on Xiaomi: SIM settings lives in com.xiaomi.simactivate.service, NOT com.android.settings
            # CRITICAL: Mobile Networks page runs in com.android.phone process!
            am force-stop com.android.settings 2>/dev/null
            am force-stop com.xiaomi.misettings 2>/dev/null
            am force-stop com.xiaomi.simactivate.service 2>/dev/null

            # ── Step 6: Force com.android.phone to re-read subscription data ──
            # Can't force-stop com.android.phone (it's the telephony service!) so instead:
            # 1. Send SIM_STATE_CHANGED broadcast to trigger re-read
            # 2. Use SubscriptionManager.setPhoneNumber via service call
            am broadcast -a android.telephony.action.SUBSCRIPTION_CARRIER_IDENTITY_CHANGED 2>/dev/null
            am broadcast -a android.intent.action.ACTION_SUBINFO_RECORD_UPDATED 2>/dev/null
            am broadcast -a android.intent.action.ACTION_SUBINFO_CONTENT_CHANGE 2>/dev/null

            # ── Step 7: Direct ISub.setPhoneNumber via service call (updates in-memory cache!) ──
            # This calls SubscriptionManagerService.setPhoneNumber() which updates BOTH DB and cache
            # Transaction code for setPhoneNumber varies by Android version; try both
            # On Android 14+: ISub.setPhoneNumber(int subId, int source, String number)
            # source: 1=CARRIER, 2=IMS
            service call isub 37 i32 1 i32 1 s16 "$CURR_NUM" 2>/dev/null
            service call isub 37 i32 1 i32 2 s16 "$CURR_NUM" 2>/dev/null
            log -t "$TAG" -p i "CONFIG WATCHER: Sent setPhoneNumber via service call"

            LAST_SPOOF_NUM="$CURR_NUM"
            log -t "$TAG" -p i "CONFIG WATCHER: ✓ SIM number live-updated → $CURR_NUM (DB=$DB_NUM)"
        fi
    done
) &

log -t "$TAG" -p i "CONFIG WATCHER PID: $!"
